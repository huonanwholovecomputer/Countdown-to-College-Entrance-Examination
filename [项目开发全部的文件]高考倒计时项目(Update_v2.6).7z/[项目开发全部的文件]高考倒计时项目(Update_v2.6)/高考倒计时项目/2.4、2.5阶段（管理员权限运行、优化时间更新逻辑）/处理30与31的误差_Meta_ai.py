from datetime import date, timedelta
from dateutil.relativedelta import relativedelta

# 定义目标日期
date_year = date(2025, 6, 7)  # 2025年6月7日

# 获取当前日期
current_date = date.today()

# 计算相对时间差
rd = relativedelta(date_year, current_date)

# 输出结果
print(f"距离{date_year}还有{rd.months}个月{rd.days}天。")
