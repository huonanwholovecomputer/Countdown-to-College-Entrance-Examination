def remove_trailing_spaces_from_empty_lines(file_path):
    with open(file_path, 'r', encoding='utf-8') as file:
        lines = file.readlines()

    # 去除空行中的多余空格
    cleaned_lines = []
    for line in lines:
        if line.strip() == '':
            cleaned_lines.append('\n')  # 保留空行但删除空格
        else:
            cleaned_lines.append(line)

    # 将处理后的内容写回文件
    with open(file_path, 'w', encoding='utf-8') as file:
        file.writelines(cleaned_lines)
    print("处理了一个问题")

file_path = "C:\\Users\\Administrator\\Desktop\\高考倒计时v2.6.py"

# 调用函数并传入你的文件路径
remove_trailing_spaces_from_empty_lines(file_path)

