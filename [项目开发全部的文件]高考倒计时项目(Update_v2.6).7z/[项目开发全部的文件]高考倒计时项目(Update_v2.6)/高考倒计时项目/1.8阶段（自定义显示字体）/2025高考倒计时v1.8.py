from tkinter import simpledialog, Tk, Label, font  # 提供简单的对话框、Tkinter主窗口、标签组件和字体管理
from PIL import Image, ImageTk  # 提供图像处理功能和Tkinter兼容的图像显示
from datetime import datetime  # 提供日期和时间的处理
import win32com.client  # 提供访问Windows COM对象的接口
import threading  # 提供线程管理和同步支持
import socket  # 提供网络套接字通信功能
import ctypes  # 提供调用C语言类型库的接口
import pystray  # 提供创建系统托盘图标的功能
import json  # 提供JSON数据编码和解码功能
import os  # 提供操作系统依赖的接口函数

# 设置 DPI 感知，改善在高 DPI 设置下的显示效果
ctypes.windll.shcore.SetProcessDpiAwareness(1)

# 程序的运行标识，用于接收"show"信息
HOST = "localhost"
PORT = 65432

# 构建相关文件的目录
config_path = os.path.join(os.path.expanduser("~"), r"AppData\Roaming\Countdown_software\config.json")
shortcut_path = r"C:\ProgramData\Microsoft\Windows\Start Menu\Programs\StartUp\2025高考倒计时.lnk"
exe_path = os.path.abspath(__file__)

# def保存配置
def save_config(config_data):
    os.makedirs(os.path.dirname(config_path), exist_ok=True)
    with open(config_path, "w", encoding="utf-8") as config_file:
        json.dump(config_data, config_file, ensure_ascii=False, indent=4)

# def加载配置
def load_config(config_path):
    if os.path.exists(config_path):
        try:
            with open(config_path, "r", encoding="utf-8") as file:
                config_data = json.load(file)
                return config_data
        except json.JSONDecodeError:
            os.remove(config_path)
            return None
    else:
        return None

# def发送显示窗口的信息
def send_show_request():
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        try:
            s.connect((HOST, PORT))
            s.sendall(b"show")
            return True
        except ConnectionRefusedError:
            return False

# 定义一个名为GUI的类
class GUI:
    # __init__ 方法是一个特殊的方法，当创建类的新实例时自动调用。这个方法内的 self 参数代表类的实例本身。
    def __init__(self, condition, font_name, font_size, time_format, window_width, window_height, position_right, position_down):
        self.root = Tk()
        self.root.title("距离2025年高考还有")
        self.root.protocol("WM_DELETE_WINDOW", self.toggle_window_visibility)

        # 变量的使用
        self.root.overrideredirect(condition)
        custom_font = font.Font(family=font_name, size=font_size)
        self.current_format = time_format
        self.root.geometry(f"+{position_right}+{position_down}")
        self.root.geometry(f"{window_width}x{window_height}")

        self.time_label = Label(self.root, text="", font=custom_font, width=10)
        self.time_label.pack(pady=0)

        self.create_systray_icon()
        self.update_time()

        self.running = True  #控制循环的标识
        threading.Thread(target=self.handle_requests, daemon=True).start()  # 启动处理请求的线程（多线程）

    # def更新时间
    def update_time(self):
        if not self.running:
            return

        now = datetime.now()
        target_date = datetime(2025, 6, 7)
        countdown = target_date - now
        self.days, seconds = countdown.days, countdown.seconds
        self.hours = seconds // 3600
        self.minutes = (seconds % 3600) // 60
        self.seconds = seconds % 60

        if self.current_format == 1:
            time_str = f"{self.days} 天 {self.hours} 小时 {self.minutes} 分 {self.seconds} 秒"
        elif self.current_format == 2:
            time_str = f"{self.days} 天 {self.hours} 小时 {self.minutes} 分"
        elif self.current_format == 3:
            time_str = f"{self.days} 天 {self.hours} 小时"
        elif self.current_format == 4:
            time_str = f"{self.days} 天"

        self.time_label.config(text=time_str)
        self.root.after(1000, self.update_time)

    # def修改时间格式
    def change_time_format(self, format_type):
        format_dict = {
            1: f"{self.days} 天 {self.hours} 小时 {self.minutes} 分 {self.seconds} 秒",
            2: f"{self.days} 天 {self.hours} 小时 {self.minutes} 分",
            3: f"{self.days} 天 {self.hours} 小时",
            4: f"{self.days} 天"
        }
        if format_type in format_dict:  # 确保 format_type 是有效的键
            self.time_label.config(text=format_dict[format_type])
            self.current_format = format_type

    # def转换窗口模式
    def conversion(self):
        self.condition = not self.condition  # 切换condition的值
        self.root.overrideredirect(self.condition)  # 更新窗口模式

    # def显示/隐藏窗口
    def toggle_window_visibility(self, icon=None, item=None):
        if self.root.state() == "withdrawn":
            self.show_window()
        else:
            self.hide_window()

    # def隐藏窗口
    def hide_window(self):
        self.root.withdraw()  # 隐藏窗口

    # def显示窗口
    def show_window(self):
        self.icon.visible = True
        self.root.deiconify()  # 恢复窗口
        self.root.state("normal")  # 确保窗口恢复正常状态

    # def退出程序
    def quit_window(self, icon: pystray.Icon, item=None):
        # 获取窗口的位置和尺寸
        position = root.winfo_x(), root.winfo_y()
        size = root.winfo_width(), root.winfo_height()
        self.running = False  # 停止更新循环
        self.root.after(0, self._quit_window)  # 在主线程中执行退出操作

    # def结束所有活动
    def _quit_window(self):
        self.icon.stop()  # 停止 Pystray 的事件循环
        self.root.quit()  # 终止 Tkinter 的事件循环
        self.root.destroy()  # 销毁应用程序的主窗口和所有活动

    # def接收信息的端口
    def handle_requests(self):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.bind((HOST, PORT))
            s.listen()
            while True:
                conn, addr = s.accept()
                with conn:
                    data = conn.recv(1024)
                    if data == b"show":
                        self.show_window()

#（1.5版本新增）```

    # def修改字体大小
    def change_font_size(self, icon, item):
        new_font_size = simpledialog.askinteger("字体大小", "请输入新的字体大小：", initialvalue=self.custom_font["size"])
        if new_font_size:
            self.custom_font.config(size=new_font_size)
            print(f"调试信息：修改了字体大小：{new_font_size}")
# ```

#（1.6版本新增）```

    # def获取lnk文件内部指向的exe程序路径
    def get_shortcut_target(shortcut_path):
        shell = win32com.client.Dispatch("WScript.Shell")
        shortcut = shell.CreateShortcut(shortcut_path)
        return os.path.abspath(shortcut.TargetPath)
    # 使用`win32com.client.Dispatch("WScript.Shell")`来创建Shell对象，通过`CreateShortcut`方法加载快捷方式文件，并通过`TargetPath`属性获取快捷方式指向的目标路径。

    # def核对快捷方式指向的的路径与本程序路径是否一致
    def is_target_correct(expected_exe_path, shortcut_path):
        actual_exe_path = get_shortcut_target(shortcut_path)
        return actual_exe_path.lower() == os.path.abspath(expected_exe_path).lower()
    # 使用`get_shortcut_target`函数获取快捷方式的目标路径，然后与预期的exe路径进行比较。为了忽略大小写差异，将两个路径都转换为小写再进行比较。

    # def检测并修正快捷方式是否正确地指向了本exe程序
    def check_shortcut_lnk(self, exe_path, shortcut_path):
        if is_target_correct(exe_path, shortcut_path):
            print("调试信息：快捷方式所指向的exe程序符合预期。")
        else:
            print("调试信息：快捷方式所指向的exe程序不符合预期。\n\n自动纠正了快捷方式指向的程序路径。")
            self.create_shortcut()

    # 创建程序快捷方式
    def create_shortcut(self, exe_path, shortcut_path):
        shell = win32com.client.Dispatch("WScript.Shell")
        shortcut = shell.CreateShortCut(shortcut_path)
        shortcut.Targetpath = exe_path
        shortcut.WorkingDirectory = os.path.dirname(exe_path)
        shortcut.save()
        print(f"调试信息：快捷方式已创建：{shortcut_path}")

    # 删除快捷方式
    def remove_shortcut(self, shortcut_path):
        os.remove(shortcut_path)
        print(f"调试信息：快捷方式已删除：{shortcut_path}")

    # "开机自启动"右键菜单主逻辑
    def toggle_autostart(self):
        if item.checked:
            self.remove_shortcut(shortcut_path)
        else:
            self.create_shortcut(exe_path, shortcut_path)

    # 检测快捷方式是否存在
    def is_shortcut_exist(self):
        return os.path.exists(shortcut_path)

# ```


# （1.8版本新增）```

    # 获取系统字体
    def get_system_fonts():
        font_names = list(font.families())
        return sorted(set(font_names))  # 去重并排序

    # 设置字体选择回调函数
    def set_font(font_name):
        global font_name
        print(f"选择的字体: {font_name}")

    # 生成字体菜单
    def create_font_menu():
        fonts = get_system_fonts()
        font_menu_items = [pystray.MenuItem(font_name, lambda: set_font(font_name)) for font_name in fonts]
        return pystray.Menu(*font_menu_items)

# ```
    # def创建托盘图标及右键菜单
    def create_systray_icon(self):
        precision_submenu_1 = pystray.Menu(
            pystray.MenuItem("天/时/分/秒", lambda: self.change_time_format(1), checked=lambda item: self.current_format == 1),
            pystray.MenuItem("天/时/分", lambda: self.change_time_format(2), checked=lambda item: self.current_format == 2),
            pystray.MenuItem("天/时", lambda: self.change_time_format(3), checked=lambda item: self.current_format == 3),
            pystray.MenuItem("天", lambda: self.change_time_format(4), checked=lambda item: self.current_format == 4)
        )
        precision_submenu_2 = pystray.Menu(
            pystray.MenuItem("字体大小", self.change_font_size),
            pystray.Menultem("选择字体", self.create_font_menu()),
            pystray.MenuItem("开机自启动", self.toggle_autostart, checked=lambda item: self.is_shortcut_exist())
        )
        main_menu = pystray.Menu(
            pystray.MenuItem("显示/隐藏", self.toggle_window_visibility, default=True),
            pystray.Menu.SEPARATOR,
            pystray.MenuItem("切换桌面窗口模式", self.conversion),
            pystray.Menu.SEPARATOR,
            pystray.MenuItem("精确程度", precision_submenu_1),
            pystray.Menu.SEPARATOR,
            pystray.MenuItem("其他设置", precision_submenu_2),
            pystray.Menu.SEPARATOR,
            pystray.MenuItem("退出", self.quit_window)
        )
        image = Image.open("_internal\\image.ico")
        self.icon = pystray.Icon("icon", image, "2025高考倒计时", main_menu)
        threading.Thread(target=self.icon.run, daemon=True).start()

# 主程序
if __name__ == "__main__":

# （1.7版本新增、大幅修改）```

    # 加载配置
    loaded_config = load_config(config_path)
    
    if loaded_config:
        condition = loaded_config.get("窗口模式")
        font_name = loaded_config.get("字体")
        font_size = loaded_config.get("字体大小")
        time_format = loaded_config.get("时间格式")
        position_right = loaded_config.get("窗口位置(右)")
        position_down = loaded_config.get("窗口位置(下)")
        window_width = loaded_config.get("窗口宽度")
        window_height = loaded_config.get("窗口高度")
    else:
        # 初始化Tkinter主窗口大小、尺寸
        condition = False
        time_format = 1
        font_name = Microsoft YaHei

        # 获取屏幕分辨率
        screen_width = self.root.winfo_screenwidth()
        screen_height = self.root.winfo_screenheight()

        # 基准窗口宽度、高度
        base_window_width = 3000
        base_window_height = 300
        base_font_size = 60

        # 窗口比例
        width_scale = screen_width / 3840
        height_scale = screen_height / 2160

        # 用窗口比例计算窗口大小、字体大小
        window_width = int(base_window_width * width_scale)
        window_height = int(base_window_height * height_scale)
        font_size = int(base_font_size * height_scale)

        # 计算窗口位置（默认水平居中、上移40%高度）
        position_right = int(screen_width / 2 - new_window_width / 2)
        position_down = int(screen_height / 2 - new_window_height / 2 - screen_height * 0.4)

    gui = GUI(condition, font_name, font_size, time_format, window_width, window_height, position_right, position_down)
    gui.root.mainloop()

    # 程序结束时保存配置
    config_data = {
        "窗口模式": gui.condition,
        "字体大小": gui.size,
        "字体": gui.font_name,
        "时间格式": gui.current_format,
        "窗口位置(右)": gui.position_right,
        "窗口位置(下)": gui.position_down,
        "窗口宽度": gui.window_width,
        "窗口高度": gui.window_height
    }
    save_config(config_data)
    print("调试信息：配置已保存")

# ```