import tkinter as tk
import time

class CountdownTimer:
    def __init__(self, root, duration):
        self.root = root
        self.duration = duration  # 倒计时总时间，单位为秒
        self.remaining_time = duration  # 剩余时间
        self.label = tk.Label(root, text=self.format_time(self.remaining_time), font=("Helvetica", 48))
        self.label.pack()
        self.update_interval = 1  # 初始更新间隔为1毫秒
        self.precise_update_done = False  # 标志变量，表示是否已经成功进行精确更新
        self.update_time()

    def format_time(self, seconds):
        minutes, seconds = divmod(seconds, 60)
        return f"{int(minutes):02}:{int(seconds):02}"

    def update_time(self):
        if self.remaining_time > 0:
            if not self.precise_update_done:
                # 尝试进行精确更新
                self.update_interval = 1  # 1毫秒更新一次
                self.precise_update_done = True
                self.root.after(self.update_interval, self.update_time)
            else:
                self.remaining_time -= 1
                self.label.config(text=self.format_time(self.remaining_time))
                self.update_interval = 1000  # 切换为1秒更新一次
                self.root.after(self.update_interval, self.update_time)
        else:
            self.label.config(text="Time's up!")

if __name__ == "__main__":
    root = tk.Tk()
    root.title("Countdown Timer")
    timer = CountdownTimer(root, duration=60)  # 60秒倒计时
    root.mainloop()




# 第二个例子：完全同步

from datetime import datetime, timedelta

class TimeUpdater:
    def __init__(self, root, time_label, target_date, current_format=1):
        self.root = root
        self.time_label = time_label
        self.target_date = target_date
        self.current_format = current_format
        self.running = True  # 设定为True表示开始运行
        
    def update_time(self):
        if not self.running:
            return

        now = datetime.now()
        target_date = datetime(2025, 6, 7)
        countdown = target_date - now
        self.days, seconds = countdown.days, countdown.seconds
        self.hours = seconds // 3600
        self.minutes = (seconds % 3600) // 60
        self.seconds = seconds % 60

        if self.current_format == 1:
            time_str = f"{self.days} 天 {self.hours} 小时 {self.minutes} 分 {self.seconds} 秒"
        elif self.current_format == 2:
            time_str = f"{self.days} 天 {self.hours} 小时 {self.minutes} 分"
        elif self.current_format == 3:
            time_str = f"{self.days} 天 {self.hours} 小时"
        elif self.current_format == 4:
            time_str = f"{self.days} 天"

        self.time_label.config(text=time_str)

        # 计算到下一秒的剩余时间
        now = datetime.now()
        next_second = (now + timedelta(seconds=1)).replace(microsecond=0)
        delay = (next_second - now).total_seconds() * 1000

        # 安排下一次更新
        self.root.after(int(delay), self.update_time)

# 示例使用：
# import tkinter as tk
# root = tk.Tk()
# time_label = tk.Label(root)
# time_label.pack()
# updater = TimeUpdater(root, time_label, datetime(2025, 6, 7))
# updater.update_time()
# root.mainloop()