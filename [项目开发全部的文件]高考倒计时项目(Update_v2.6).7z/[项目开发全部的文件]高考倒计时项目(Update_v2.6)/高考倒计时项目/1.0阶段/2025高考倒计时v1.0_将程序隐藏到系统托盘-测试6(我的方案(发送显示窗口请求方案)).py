import tkinter as tk
from tkinter import font
from datetime import datetime
import threading
import socket
import ctypes
import pystray
from PIL import Image

# 设置 DPI 感知，改善在高 DPI 设置下的显示效果
ctypes.windll.shcore.SetProcessDpiAwareness(1)

HOST = 'localhost'
PORT = 65432

class GUI:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("距离2025年高考还有")
        self.root.protocol('WM_DELETE_WINDOW', self.toggle_window_visibility)

        self.running = True  # 用于控制倒计时更新循环的标志

        # 使用微软雅黑字体输出
        custom_font = font.Font(family='Microsoft YaHei', size=60)

        self.time_label = tk.Label(self.root, text="", font=custom_font, width=25)
        self.time_label.pack(pady=0)

        # 固定窗口大小，使其不随标签大小变化而变化
        self.root.geometry("3000x300")  # 可根据实际情况调整窗口尺寸

        # 添加菜单和图标
        self.create_systray_icon()

        # 启动倒计时
        self.update_time()

        # 启动处理请求的线程
        threading.Thread(target=self.handle_requests, daemon=True).start()

    def update_time(self):
        if not self.running:
            return  # 如果不再运行，则退出更新循环
        now = datetime.now()
        target_date = datetime(2025, 6, 7)
        countdown = target_date - now
        days, seconds = countdown.days, countdown.seconds
        hours = seconds // 3600
        minutes = (seconds % 3600) // 60
        seconds = seconds % 60

        time_str = f"{days} 天 {hours} 小时 {minutes} 分 {seconds} 秒"
        self.time_label.config(text=time_str)
        self.root.after(1000, self.update_time)

    def create_systray_icon(self):
        """
        使用 Pystray 创建系统托盘图标
        """
        menu = (
            pystray.MenuItem('显示/隐藏', self.toggle_window_visibility, default=True),
            pystray.Menu.SEPARATOR,  # 在系统托盘菜单中添加分隔线
            pystray.MenuItem('退出', self.quit_window))
        image = Image.open("_internal\\image.ico")
        self.icon = pystray.Icon("icon", image, "2025高考倒计时", menu)
        threading.Thread(target=self.icon.run, daemon=True).start()

    def toggle_window_visibility(self, icon=None, item=None):
        if self.root.state() == 'withdrawn':
            self.show_window()
        else:
            self.hide_window()

    def hide_window(self):
        self.root.withdraw()  # 隐藏窗口

    def show_window(self):
        self.icon.visible = True
        self.root.deiconify()  # 恢复窗口
        self.root.state('normal')  # 确保窗口恢复正常状态

    def quit_window(self, icon: pystray.Icon, item=None):
        """
        退出程序
        """
        self.running = False  # 停止更新循环
        self.root.after(0, self._quit_window)  # 在主线程中执行退出操作

    def _quit_window(self):
        self.icon.stop()  # 停止 Pystray 的事件循环
        self.root.quit()  # 终止 Tkinter 的事件循环
        self.root.destroy()  # 销毁应用程序的主窗口和所有活动

    def handle_requests(self):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.bind((HOST, PORT))
            s.listen()
            while True:
                conn, addr = s.accept()
                with conn:
                    data = conn.recv(1024)
                    if data == b'show':
                        self.show_window()

def send_show_request():
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        try:
            s.connect((HOST, PORT))
            s.sendall(b'show')
            return True
        except ConnectionRefusedError:
            return False

if __name__ == "__main__":
    if not send_show_request():
        gui = GUI()
        gui.root.mainloop()
