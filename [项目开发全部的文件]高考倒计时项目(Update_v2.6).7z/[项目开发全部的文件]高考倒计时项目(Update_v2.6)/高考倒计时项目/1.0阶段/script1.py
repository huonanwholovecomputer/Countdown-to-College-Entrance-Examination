import tkinter as tk
import socket
import threading

root = tk.Tk()

def hide_window():
    global root
    root.withdraw()

def show_window():
    global root
    root.deiconify()
    root.state('normal')

def handle_requests():
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(('localhost', 65432))
        s.listen()
        while True:
            conn, addr = s.accept()
            with conn:
                data = conn.recv(1024)
                if data == b'show':
                    show_window()

threading.Thread(target=handle_requests, daemon=True).start()

# 示例按钮以隐藏窗口
btn_hide = tk.Button(root, text="Hide", command=hide_window)
btn_hide.pack()

# 启动主循环
root.mainloop()
