import tkinter as tk
import socket
import threading

HOST = 'localhost'
PORT = 65432

def hide_window():
    global root
    root.withdraw()

def show_window():
    global root
    root.deiconify()
    root.state('normal')

def handle_requests():
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind((HOST, PORT))
        s.listen()
        while True:
            conn, addr = s.accept()
            with conn:
                data = conn.recv(1024)
                if data == b'show':
                    show_window()

def create_window():
    global root
    root = tk.Tk()
    btn_hide = tk.Button(root, text="Hide", command=hide_window)
    btn_hide.pack()
    threading.Thread(target=handle_requests, daemon=True).start()
    root.mainloop()

def send_show_request():
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        try:
            s.connect((HOST, PORT))
            s.sendall(b'show')
            return True
        except ConnectionRefusedError:
            return False

if __name__ == "__main__":
    if not send_show_request():
        create_window()
