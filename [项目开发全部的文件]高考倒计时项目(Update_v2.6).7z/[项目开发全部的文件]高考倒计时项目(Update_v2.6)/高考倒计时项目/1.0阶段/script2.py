import socket

def send_show_request():
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.connect(('localhost', 65432))
        s.sendall(b'show')

# 发送显示窗口的请求
send_show_request()
