import os
import sys
import pystray
from PIL import Image
import ctypes
import win32gui
import win32con
import threading

import tkinter as tk
from tkinter import font
from datetime import datetime

def get_exe_icon():
    # 从当前exe文件中提取图标
    exe_path = sys.argv[0]
    large_icons = (ctypes.wintypes.HICON * 1)()
    small_icons = (ctypes.wintypes.HICON * 1)()
    num_icons = ctypes.windll.shell32.ExtractIconEx(exe_path, 0, large_icons, small_icons, 1)
    if num_icons > 0 and large_icons[0]:
        large_icon = large_icons[0]
        ico_x = win32gui.GetSystemMetrics(win32con.SM_CXICON)
        ico_y = win32gui.GetSystemMetrics(win32con.SM_CYICON)
        hdc = win32gui.CreateCompatibleDC(0)
        hbm = win32gui.CreateCompatibleBitmap(hdc, ico_x, ico_y)
        hbm_old = win32gui.SelectObject(hdc, hbm)
        win32gui.DrawIconEx(hdc, 0, 0, large_icon, ico_x, ico_y, 0, 0, win32con.DI_NORMAL)
        win32gui.SelectObject(hdc, hbm_old)
        bmpinfo = win32gui.GetObject(hbm)
        bmpstr = win32gui.GetBitmapBits(hbm, True)
        ico_image = Image.frombuffer('RGBA', (bmpinfo.bmWidth, bmpinfo.bmHeight), bmpstr, 'raw', 'BGRA', 0, 1)
        win32gui.DeleteObject(hbm)
        return ico_image
    return None

def on_quit(icon, item):
    icon.stop()
    win32gui.PostQuitMessage(0)

def main():
    # 隐藏窗口
    hide_window()

    # 创建系统托盘图标，从exe中提取图标
    icon_image = get_exe_icon()
    if icon_image is None:
        print("未能提取图标")
        return

    icon = pystray.Icon("test")
    icon.icon = icon_image
    icon.menu = pystray.Menu(pystray.MenuItem('Quit', on_quit))

    # 启动你的程序逻辑线程
    logic_thread = threading.Thread(target=your_program_logic)
    logic_thread.daemon = True
    logic_thread.start()

    # 运行系统托盘图标
    icon.run()

def hide_window():
    # 获取当前窗口句柄
    hwnd = win32gui.GetForegroundWindow()
    # 隐藏窗口
    win32gui.ShowWindow(hwnd, win32con.SW_HIDE)

def your_program_logic():
    
    # 设置 DPI 感知，改善在高 DPI 设置下的显示效果
    ctypes.windll.shcore.SetProcessDpiAwareness(1)

    def update_time():
        now = datetime.now()
        target_date = datetime(2025, 6, 7)
        countdown = target_date - now
        days, seconds = countdown.days, countdown.seconds
        hours = seconds // 3600
        minutes = (seconds % 3600) // 60
        seconds = seconds % 60
        
        time_str = f"{days} 天 {hours} 小时 {minutes} 分 {seconds} 秒"
        time_label.config(text=time_str)
        root.after(1000, update_time)  # 每秒更新一次

    root = tk.Tk()
    root.title("距离2025年高考还有")

    # 使用微软雅黑字体输出
    custom_font = font.Font(family='Microsoft YaHei', size=60)

    # 设定标签的宽度，以保持窗口大小稳定
    time_label = tk.Label(root, text="", font=custom_font, width=25)
    time_label.pack(pady=0)

    # 固定窗口大小，使其不随标签大小变化而变化
    root.geometry("3000x300")  # 可根据实际情况调整窗口尺寸

    update_time()  # 启动倒计时，调用函数update_time()

    root.mainloop()
        
if __name__ == '__main__':
    main()
