import pystray                         # 导入 PyStray 库
from PIL import Image                  # 导入 PIL 库中的 Image 模块

def on_quit_clicked(icon):             # 自定义回调函数
    icon.stop()                        # 对象停止方法

# 创建图标对象
image = Image.open("2025高考.ico")           # 打开 ICO 图像文件并创建一个 Image 对象
menu = (pystray.MenuItem(text='退出', action=on_quit_clicked),) # 创建菜单项元组
icon = pystray.Icon("name", image, "托盘名称", menu)            # 创建 PyStray Icon 对象，并传入关键参数

# 显示图标
icon.run()                              # 启动托盘图标目录
