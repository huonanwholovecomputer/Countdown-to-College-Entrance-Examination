## 获取当前exe程序路径
```python

import os

exe_path = os.path.abspath(__file__)
print("当前exe路径：", exe_path)

```

## 制作快捷方式


# 安装`pywin32`库
```cmd
pip install pywin32
```

```python

import os
import shutil
from pathlib import Path

# 定义源文件（exe程序）和快捷方式的路径
exe_path = r"C:\path\to\your\executable\your_program.exe"  # 替换为你的exe文件路径
shortcut_path = r"C:\path\where\you\want\the\shortcut\YourProgram.lnk"  # 替换为你希望创建快捷方式的位置和名称

# 确保源文件路径和目标路径正确
if not os.path.exists(exe_path):
    print(f"源文件不存在：{exe_path}")
else:
    # 创建快捷方式
    shell = Dispatch('WScript.Shell')
    shortcut = shell.CreateShortCut(shortcut_path)
    shortcut.Targetpath = exe_path
    shortcut.WorkingDirectory = os.path.dirname(exe_path)
    shortcut.save()

print(f"快捷方式已创建：{shortcut_path}")

```


## 实际应用
```python

import os
import shutil
from pathlib import Path
import win32com.client

# 获取当前程序路径
exe_path = os.path.abspath(__file__)

# 定义快捷方式的路径
shortcut_path = r"C:\ProgramData\Microsoft\Windows\Start Menu\Programs\StartUp\2025高考倒计时.lnk"

# 创建快捷方式
try:
    shell = win32com.client.Dispatch('WScript.Shell')
    shortcut = shell.CreateShortCut(shortcut_path)
    shortcut.Targetpath = exe_path
    shortcut.WorkingDirectory = os.path.dirname(exe_path)
    shortcut.save()
    print(f"快捷方式已创建：{shortcut_path}")
except Exception as e:
    print(f"创建快捷方式时发生错误：{e}")

```



### 结合右键菜单（By ChatGPT-4o）

```cmd
pip install pystray Pillow
```

```python

import pystray
from pystray import MenuItem as item
from pathlib import Path
import win32com.client

# 定义快捷方式的路径
shortcut_path = r"C:\ProgramData\Microsoft\Windows\Start Menu\Programs\StartUp\2025高考倒计时.lnk"

def create_shortcut():
    # 获取当前程序路径
    exe_path = os.path.abspath(__file__)
    # 创建快捷方式
    try:
        shell = win32com.client.Dispatch('WScript.Shell')
        shortcut = shell.CreateShortCut(shortcut_path)
        shortcut.Targetpath = exe_path
        shortcut.WorkingDirectory = os.path.dirname(exe_path)
        shortcut.save()
        print(f"快捷方式已创建：{shortcut_path}")
    except Exception as e:
        print(f"创建快捷方式时发生错误：{e}")

def remove_shortcut():
    # 删除快捷方式
    try:
        if os.path.exists(shortcut_path):
            os.remove(shortcut_path)
            print(f"快捷方式已删除：{shortcut_path}")
        else:
            print("快捷方式不存在，无需删除。")
    except Exception as e:
        print(f"删除快捷方式时发生错误：{e}")

def toggle_autostart(icon, item):
    if item.checked:
        remove_shortcut()
    else:
        create_shortcut()

def is_shortcut_exist():
    return os.path.exists(shortcut_path)

menu = (
    item("开机自启动", toggle_autostart, checked=lambda item: is_shortcut_exist())
)

```