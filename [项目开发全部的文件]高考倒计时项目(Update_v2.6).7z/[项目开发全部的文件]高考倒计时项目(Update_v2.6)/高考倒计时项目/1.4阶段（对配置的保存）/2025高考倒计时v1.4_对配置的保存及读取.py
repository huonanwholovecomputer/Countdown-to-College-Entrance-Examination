if __name__ == "__main__":
    # 加载配置
    config_data = load_config()
    
    if config_data:
        print("加载到的配置: ", config_data)
        # 应用加载到的配置，例如设置时间格式：
        time_format = config_data.get('time_format', 'HH:MM:SS')
    else:
        print("没有可用的配置，使用默认配置")
        # 默认时间格式
        time_format = 'HH:MM:SS'

    # 这里时间格式可以是 "HH:MM:SS" 或者用户指定的其他格式
    print(f"当前时间格式: {time_format}")

    # 在程序运行过程中，用户可以更改时间格式
    new_time_format = input("请输入新的时间格式: ")
    
    # 更新配置
    config_data = {
        'time_format': new_time_format
    }
    
    # 保存配置
    save_config(config_data)
    print("配置已保存")
