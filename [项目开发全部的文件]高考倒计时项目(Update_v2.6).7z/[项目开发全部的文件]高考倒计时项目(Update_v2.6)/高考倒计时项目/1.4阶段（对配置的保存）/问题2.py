import os
import json
import threading
from PIL import Image, ImageTk
import pystray
from tkinter import Tk, Label, font

#  导入相关模块

config_path = r'C:\Users\Administrator\AppData\Roaming\Countdown_software\config.json'

def save_config(config_data):
    try:
        os.makedirs(os.path.dirname(config_path), exist_ok=True)
        with open(config_path, 'w', encoding='utf-8') as config_file:
            json.dump(config_data, config_file, ensure_ascii=False, indent=4)
            print(f"配置已成功保存到 {config_path}")
    except Exception as e:
        print(f"保存配置时发生错误: {e}")

def load_config(config_path):
    if os.path.exists(config_path):
        try:
            with open(config_path, 'r', encoding='utf-8') as file:
                config_data = json.load(file)
                if "time_format" in config_data:
                    return config_data["time_format"]
        except FileNotFoundError:
            print("配置文件未找到")
        except json.JSONDecodeError:
            print("配置文件格式错误")
        return None
    else:
        print(f"配置文件 {config_path} 不存在")
        return None

class GUI:
    def __init__(self, time_format):
        self.root = Tk()
        self.root.title("距离2025年高考还有")
        self.condition = False  # 使用self.condition
        self.root.overrideredirect(self.condition)
        self.root.protocol('WM_DELETE_WINDOW', self.toggle_window_visibility)

        self.running = True  # 用于控制倒计时更新循环的标志
        
        screen_width = self.root.winfo_screenwidth()
        screen_height = self.root.winfo_screenheight()
        
        base_window_width = 3000
        base_window_height = 300
        base_font_size = 60
        
        width_scale = screen_width / 3840
        height_scale = screen_height / 2160
        
        new_window_width = int(base_window_width * width_scale)
        new_window_height = int(base_window_height * height_scale)
        new_font_size = int(base_font_size * height_scale)
        
        position_right = int(screen_width / 2 - new_window_width / 2)
        position_down = int(screen_height / 2 - new_window_height / 2 - screen_height * 0.4)
        self.root.geometry(f"+{position_right}+{position_down}")
        
        custom_font = font.Font(family='Microsoft YaHei', size=new_font_size)

        self.time_label = Label(self.root, text="", font=custom_font, width=25)
        self.time_label.pack(pady=0)

        self.current_format = time_format
        
        self.create_systray_icon()
        self.update_time_label()

        self.update_time()

        # 启动处理请求的线程
        threading.Thread(target=self.handle_requests, daemon=True).start()

    def update_time_label(self):
        # 假设这里是你原来的 change_time_format 方法
        format_dict = {
            1: f"{self.days} 天 {self.hours} 小时 {self.minutes} 分 {self.seconds} 秒",
            2: f"{self.days} 天 {self.hours} 小时 {self.minutes} 分",
            3: f"{self.days} 天 {self.hours} 小时",
            4: f"{self.days} 天"
        }
        if self.current_format in format_dict:  # 确保 current_format 是有效的键
            self.time_label.config(text=format_dict[self.current_format])

    def toggle_window_visibility(self):
        self.condition = not self.condition
        self.root.overrideredirect(self.condition)

    def create_systray_icon(self):
        precision_submenu = pystray.Menu(
            pystray.MenuItem('天/时/分/秒', lambda: self.change_time_format(1), checked=lambda item: self.current_format == 1),
            pystray.MenuItem('天/时/分', lambda: self.change_time_format(2), checked=lambda item: self.current_format == 2),
            pystray.MenuItem('天/时', lambda: self.change_time_format(3), checked=lambda item: self.current_format == 3),
            pystray.MenuItem('天', lambda: self.change_time_format(4), checked=lambda item: self.current_format == 4)
        )
        main_menu = pystray.Menu(
            pystray.MenuItem('精确程度', precision_submenu),
        )
        image = Image.open("_internal\\image.ico")
        self.icon = pystray.Icon("icon", image, "2025高考倒计时", main_menu)
        threading.Thread(target=self.icon.run, daemon=True).start()

    def update_time(self):
        # 这里是更新倒计时的逻辑，根据需要实现
        pass

    def handle_requests(self):
        # 这里是处理请求的逻辑，根据需要实现
        pass

#  主程序
if __name__ == "__main__":
    time_format = load_config(config_path)
    if time_format is not None:
       print("加载到的配置: ", time_format)
    else:
        print("没有可用的配置，使用默认配置")
        time_format = 1

    # 主要的运行逻辑
    gui = GUI(time_format)
    gui.root.mainloop()
    
    # 程序结束时保存配置
    config_data = {'time_format': gui.current_format}
    save_config(config_data)
    print("配置已保存")
