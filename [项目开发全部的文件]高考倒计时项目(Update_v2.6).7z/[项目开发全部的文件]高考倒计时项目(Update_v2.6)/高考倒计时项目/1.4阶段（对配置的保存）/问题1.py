import os
import json
import threading
from PIL import Image
import pystray
from tkinter import Tk, Label

#  导入相关模块

config_path = r'C:\Users\Administrator\AppData\Roaming\Countdown_software\config.json'

def save_config(config_data):
    try:
        os.makedirs(os.path.dirname(config_path), exist_ok=True)
        with open(config_path, 'w', encoding='utf-8') as config_file:
            json.dump(config_data, config_file, ensure_ascii=False, indent=4)
            print(f"配置已成功保存到 {config_path}")
    except Exception as e:
        print(f"保存配置时发生错误: {e}")

def load_config(config_path):
    if os.path.exists(config_path):
        try:
            with open(config_path, 'r', encoding='utf-8') as file:
                config_data = json.load(file)
                if "time_format" in config_data:
                    return config_data["time_format"]
        except FileNotFoundError:
            print("配置文件未找到")
        except json.JSONDecodeError:
            print("配置文件格式错误")
        return None
    else:
        print(f"配置文件 {config_path} 不存在")
        return None

class GUI:
    def __init__(self, time_format):
        self.root = Tk()
        self.time_label = Label(self.root)
        self.time_label.pack()
        self.current_format = time_format
        self.days = 0
        self.hours = 0
        self.minutes = 0
        self.seconds = 0
        self.create_systray_icon()
        self.update_time_label()

    def update_time_label(self):
        self.change_time_format(self.current_format)
        self.root.after(1000, self.update_time_label)

    def change_time_format(self, format_type):
        format_dict = {
            1: f"{self.days} 天 {self.hours} 小时 {self.minutes} 分 {self.seconds} 秒",
            2: f"{self.days} 天 {self.hours} 小时 {self.minutes} 分",
            3: f"{self.days} 天 {self.hours} 小时",
            4: f"{self.days} 天"
        }
        if format_type in format_dict:  # 确保 format_type 是有效的键
            self.time_label.config(text=format_dict[format_type])
            self.current_format = format_type
            
    def create_systray_icon(self):
        precision_submenu = pystray.Menu(
            pystray.MenuItem('天/时/分/秒', lambda: self.change_time_format(1), checked=lambda item: self.current_format == 1),
            pystray.MenuItem('天/时/分', lambda: self.change_time_format(2), checked=lambda item: self.current_format == 2),
            pystray.MenuItem('天/时', lambda: self.change_time_format(3), checked=lambda item: self.current_format == 3),
            pystray.MenuItem('天', lambda: self.change_time_format(4), checked=lambda item: self.current_format == 4)
        )
        main_menu = pystray.Menu(
            pystray.MenuItem('精确程度', precision_submenu),
        )
        image = Image.open("_internal\\image.ico")
        self.icon = pystray.Icon("icon", image, "2025高考倒计时", main_menu)
        threading.Thread(target=self.icon.run, daemon=True).start()

#  主程序
if __name__ == "__main__":
    time_format = load_config(config_path)
    if time_format is not None:
       print("加载到的配置: ", time_format)
    else:
        print("没有可用的配置，使用默认配置")
        time_format = 1

    # 主要的运行逻辑
    gui = GUI(time_format)
    gui.root.mainloop()
    
    # 程序结束时保存配置
    config_data = {'time_format': gui.current_format}
    save_config(config_data)
    print("配置已保存")
