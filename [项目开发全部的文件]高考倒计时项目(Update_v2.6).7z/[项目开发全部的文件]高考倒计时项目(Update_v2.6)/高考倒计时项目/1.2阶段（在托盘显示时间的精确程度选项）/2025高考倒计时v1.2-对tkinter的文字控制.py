import tkinter as tk
import threading
import pystray
from PIL import Image
import time

class App:
    def __init__(self, root):
        self.root = root
        self.time_str = tk.StringVar(self.root, value="倒计时")
        self.days, self.hours, self.minutes, self.seconds = 0, 0, 0, 0

        self.label = tk.Label(self.root, textvariable=self.time_str, font=("Arial", 24))
        self.label.pack(pady=20)
        
        self.create_systray_icon()

    def change_time_format(self, format_type):
        format_dict = {
            1: f"{self.days} 天 {self.hours} 小时 {self.minutes} 分 {self.seconds} 秒",
            2: f"{self.days} 天 {self.hours} 小时 {self.minutes} 分",
            3: f"{self.days} 天 {self.hours} 小时",
            4: f"{self.days} 天"
        }
        self.time_str.set(format_dict[format_type])

    def create_systray_icon(self):
        """
        使用 Pystray 创建系统托盘图标
        """
        menu = pystray.Menu(
            pystray.MenuItem('显示/隐藏', self.toggle_window_visibility, default=True),
            pystray.Menu.SEPARATOR,
            pystray.MenuItem('切换桌面窗口模式', self.conversion),
            pystray.Menu.SEPARATOR,
            pystray.MenuItem("精确程度：", action=None, enabled=False),
            pystray.MenuItem('天/时/分/秒', lambda: self.change_time_format(1)),
            pystray.MenuItem('天/时/分', lambda: self.change_time_format(2)),
            pystray.MenuItem('天/时', lambda: self.change_time_format(3)),
            pystray.MenuItem('天', lambda: self.change_time_format(4)),
            pystray.Menu.SEPARATOR,
            pystray.MenuItem('退出', self.quit_window)
        )

        image = Image.open("_internal\\image.ico")
        self.icon = pystray.Icon("icon", image, "2025高考倒计时", menu)
        threading.Thread(target=self.icon.run, daemon=True).start()
    
    def toggle_window_visibility(self):
        if self.root.state() == 'normal':
            self.root.withdraw()
        else:
            self.root.deiconify()

    def conversion(self):
        print("Conversion logic here")

    def quit_window(self):
        self.icon.stop()
        self.root.quit()

if __name__ == "__main__":
    root = tk.Tk()
    app = App(root)
    root.mainloop()
