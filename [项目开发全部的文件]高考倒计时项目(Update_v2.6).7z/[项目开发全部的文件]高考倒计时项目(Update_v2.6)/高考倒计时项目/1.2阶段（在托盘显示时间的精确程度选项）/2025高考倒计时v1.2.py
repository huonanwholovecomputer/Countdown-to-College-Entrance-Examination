import tkinter as tk
from tkinter import font
from datetime import datetime
import threading
import socket
import ctypes
import pystray
from PIL import Image

# 设置 DPI 感知，改善在高 DPI 设置下的显示效果
ctypes.windll.shcore.SetProcessDpiAwareness(1)

HOST = 'localhost'
PORT = 65432

global condition

class GUI: 
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("距离2025年高考还有")
        self.condition = True  # 使用self.condition
        self.root.overrideredirect(self.condition)
        self.root.protocol('WM_DELETE_WINDOW', self.toggle_window_visibility)

        self.running = True  # 用于控制倒计时更新循环的标志
        
        screen_width = self.root.winfo_screenwidth()
        screen_height = self.root.winfo_screenheight()
        
        base_window_width = 3000
        base_window_height = 300
        base_font_size = 60
        
        width_scale = screen_width / 3840
        height_scale = screen_height / 2160
        
        new_window_width = int(base_window_width * width_scale)
        new_window_height = int(base_window_height * height_scale)
        new_font_size = int(base_font_size * height_scale)
        
        position_right = int(screen_width / 2 - new_window_width / 2)
        position_down = int(screen_height / 2 - new_window_height / 2 - screen_height * 0.4)
        self.root.geometry(f"+{position_right}+{position_down}")
        
        custom_font = font.Font(family='Microsoft YaHei', size=new_font_size)
        
        self.time_label = tk.Label(self.root, text="", font=custom_font, width=25)
        self.time_label.pack(pady=0)
        
        self.root.geometry(f"{new_window_width}x{new_window_height}")

        self.create_systray_icon()

        self.update_time()

    def update_time(self):
        if not self.running:
            return  # 如果不再运行，则退出更新循环
        now = datetime.now()
        target_date = datetime(2025, 6, 7)
        countdown = target_date - now
        self.days = countdown.days
        seconds = countdown.seconds
        self.hours = seconds // 3600
        self.minutes = (seconds % 3600) // 60
        self.seconds = seconds % 60
        self.current_format = f"{self.days} 天 {self.hours} 小时 {self.minutes} 分 {self.seconds} 秒"
        self.change_time_format(self.current_format)  # 更新显示的时间格式
        self.root.after(1000, self.update_time)

    def change_time_format(self, format_type):
        format_dict = {
            1: f"{self.days} 天 {self.hours} 小时 {self.minutes} 分 {self.seconds} 秒",
            2: f"{self.days} 天 {self.hours} 小时 {self.minutes} 分",
            3: f"{self.days} 天 {self.hours} 小时",
            4: f"{self.days} 天"
        }
        self.time_label.config(text=format_dict[format_type])
        self.current_format = format_type  # 记录当前格式类型

    def create_systray_icon(self):
        """
        使用 Pystray 创建系统托盘图标
        """
        menu = pystray.Menu(
            pystray.MenuItem('显示/隐藏', self.toggle_window_visibility, default=True),
            pystray.Menu.SEPARATOR,
            pystray.MenuItem('切换桌面窗口模式', self.conversion),
            pystray.Menu.SEPARATOR,
            pystray.MenuItem("精确程度：", action=None, enabled=False),
            pystray.MenuItem('天/时/分/秒', lambda: self.change_time_format(1)),
            pystray.MenuItem('天/时/分', lambda: self.change_time_format(2)),
            pystray.MenuItem('天/时', lambda: self.change_time_format(3)),
            pystray.MenuItem('天', lambda: self.change_time_format(4)),
            pystray.Menu.SEPARATOR,
            pystray.MenuItem('退出', self.quit_window)
        )

        image = Image.open("_internal\\image.ico")
        self.icon = pystray.Icon("icon", image, "2025高考倒计时", menu)
        threading.Thread(target=self.icon.run, daemon=True).start()

    # 定义转换窗口模式
    def conversion(self):
        self.condition = not self.condition  # 切换condition的值
        self.root.overrideredirect(self.condition)  # 更新窗口模式

    def toggle_window_visibility(self, icon=None, item=None):
        if self.root.state() == 'withdrawn':
            self.show_window()
        else:
            self.hide_window()

    def hide_window(self):
        self.root.withdraw()  # 隐藏窗口

    def show_window(self):
        self.icon.visible = True
        self.root.deiconify()  # 恢复窗口
        self.root.state('normal')  # 确保窗口恢复正常状态

    def quit_window(self, icon: pystray.Icon, item=None):
        """
        退出程序
        """
        self.running = False  # 停止更新循环
        self.root.after(0, self._quit_window)  # 在主线程中执行退出操作

    def _quit_window(self):
        self.icon.stop()  # 停止 Pystray 的事件循环
        self.root.quit()  # 终止 Tkinter 的事件循环
        self.root.destroy()  # 销毁应用程序的主窗口和所有活动

    def handle_requests(self):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.bind((HOST, PORT))
            s.listen()
            while True:
                conn, addr = s.accept()
                with conn:
                    data = conn.recv(1024)
                    if data == b'show':
                        self.show_window()

def send_show_request():
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        try:
            s.connect((HOST, PORT))
            s.sendall(b'show')
            return True
        except ConnectionRefusedError:
            return False

if __name__ == "__main__":
    if not send_show_request():
        root = tk.Tk()
        gui = GUI()
        gui.root.mainloop()
