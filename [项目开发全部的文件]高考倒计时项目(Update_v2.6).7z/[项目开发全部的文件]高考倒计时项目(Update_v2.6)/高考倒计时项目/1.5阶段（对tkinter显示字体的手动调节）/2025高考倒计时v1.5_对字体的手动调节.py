import tkinter as tk
from tkinter import simpledialog, font
import pystray
from PIL import Image
import threading

class MyApp:
    def __init__(self):
        self.root = tk.Tk()
        self.root.withdraw()  # Hide the main window
        self.default_font_size = 12  # Set the default font size
        self.custom_font = font.Font(family="Microsoft YaHei", size=self.default_font_size)
        self.create_systray_icon()

    def change_font_size(self, icon, item):
        # Prompt the user for a new font size
        new_font_size = simpledialog.askinteger("字体大小", "请输入新的字体大小：", initialvalue=self.custom_font['size'])
        if new_font_size:
            self.custom_font.config(size=new_font_size)
            print(f"Font size changed to {new_font_size}")  # Debug message, can be removed

    def create_systray_icon(self):
        precision_submenu_2 = pystray.Menu(
            pystray.MenuItem("字体大小", self.change_font_size)
        )
        main_menu = pystray.Menu(
            pystray.MenuItem("其他设置", precision_submenu_2)
        )
        image = Image.open("_internal\\image.ico")
        self.icon = pystray.Icon("icon", image, "2025高考倒计时", main_menu)
        threading.Thread(target=self.icon.run, daemon=True).start()

if __name__ == "__main__":
    app = MyApp()
    app.root.mainloop()