import tkinter as tk
from tkinter import font
import ctypes

class MyApp:
    def __init__(self, root):
        self.root = root
        self.initialize_ui()

    def get_system_dpi_scale(self):
        # 获取当前屏幕的 DPI 缩放比例
        user32 = ctypes.windll.user32
        gdi32 = ctypes.windll.gdi32
        
        # 获得屏幕的逻辑 DPI（显示设置中的缩放比例）
        hdc = user32.GetDC(0)
        dpi_x = gdi32.GetDeviceCaps(hdc, 88)  # 88是LOGPIXELSX
        user32.ReleaseDC(0, hdc)
        
        # Windows的默认DPI是96，所以要除以96来获得比例
        scale_factor = dpi_x / 96.0
        return scale_factor

    def initialize_ui(self):
        screen_width = self.root.winfo_screenwidth()
        screen_height = self.root.winfo_screenheight()

        base_window_width = 3000
        base_window_height = 300
        base_font_size = 60

        dpi_scale = self.get_system_dpi_scale()

        width_scale = screen_width / 3840
        height_scale = screen_height / 2160

        new_window_width = int(base_window_width * width_scale * dpi_scale)
        new_window_height = int(base_window_height * height_scale * dpi_scale)
        new_font_size = int(base_font_size * height_scale * dpi_scale)

        position_right = int(screen_width / 2 - new_window_width / 2)
        position_down = int(screen_height / 2 - new_window_height / 2 - screen_height * 0.4)
        self.root.geometry(f"+{position_right}+{position_down}")

        custom_font = font.Font(family='Microsoft YaHei', size=new_font_size)

        self.time_label = tk.Label(self.root, text="", font=custom_font, width=10)
        self.time_label.pack(pady=0)

        self.root.geometry(f"{new_window_width}x{new_window_height}")

if __name__ == "__main__":
    root = tk.Tk()
    app = MyApp(root)
    root.mainloop()