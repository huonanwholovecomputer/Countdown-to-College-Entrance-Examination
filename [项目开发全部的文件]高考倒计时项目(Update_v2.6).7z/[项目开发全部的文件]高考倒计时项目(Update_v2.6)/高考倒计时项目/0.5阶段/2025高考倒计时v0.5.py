import tkinter as tk
from tkinter import font
from datetime import datetime
import ctypes

# 设置 DPI 感知，改善在高 DPI 设置下的显示效果
ctypes.windll.shcore.SetProcessDpiAwareness(1)

def update_time():
    now = datetime.now()
    target_date = datetime(2025, 6, 7)
    countdown = target_date - now
    days, seconds = countdown.days, countdown.seconds
    hours = seconds // 3600
    minutes = (seconds % 3600) // 60
    seconds = seconds % 60
    
    time_str = f"{days} 天 {hours} 小时 {minutes} 分 {seconds} 秒"
    time_label.config(text=time_str)
    root.after(1000, update_time)  # 每秒更新一次

root = tk.Tk()
root.title("距离2025年高考还有")

# 使用微软雅黑字体输出
custom_font = font.Font(family='Microsoft YaHei', size=60)

# 设定标签的宽度，以保持窗口大小稳定
time_label = tk.Label(root, text="", font=custom_font, width=25)
time_label.pack(pady=0)

# 固定窗口大小，使其不随标签大小变化而变化
root.geometry("3000x300")  # 可根据实际情况调整窗口尺寸

update_time()  # 启动倒计时，调用函数update_time()

root.mainloop()
