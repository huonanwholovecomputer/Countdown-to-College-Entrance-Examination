class GUI:
    def __init__(self):
        self.running = True
        self.initialize(date_year)
        self.create_systray_icon()
        self.update_time()
    
    def initialize(self, date_year):
        self.date_year = date_year
    
    def update_time(self):
            if not self.running:
                return
            now = datetime.now()
            target_date = datetime(self.date_year, 6, 7)
            countdown = target_date - now
            # 省略了一些代码
            self.root.after(1000, self.update_time)
    
    def create_systray_icon(self):
        precision_submenu_2_1 = pystray.Menu(
            pystray.MenuItem(str(date_year), lambda: self.return_date_year(date_year), checked=lambda item: self.date_year==date_year),
            pystray.MenuItem(str(date_year+1), lambda: self.return_date_year(date_year+1), checked=lambda item: self.date_year==date_year+1),
            pystray.MenuItem(str(date_year+2), lambda: self.return_date_year(date_year+2), checked=lambda item: self.date_year==date_year+2)
        )
        pystray.MenuItem("选择高考年份",precision_submenu_2_1),
        main_menu = pystray.Menu(
        pystray.MenuItem("其他设置", precision_submenu_2),
        )
        image = Image.open("_internal\\image.ico")
        self.icon = pystray.Icon("icon", image, "高考倒计时", main_menu)
        threading.Thread(target=self.icon.run, daemon=True).start()
    
    if __name__ == "__main__":
        gui = GUI()
        gui.root.mainloop()