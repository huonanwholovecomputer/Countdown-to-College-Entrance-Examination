font_size = 60  # 这里你可以设置任何你需要的 font_size 值

# 创建包含 font_size 及其前后 10 个数值的列表
size_list = list(range(font_size - 15, font_size + 16))

print(size_list)
