通过在右键菜单中内嵌 `Entry` 小部件来实现输入数字功能


这是一个示例代码：
```
import tkinter as tk

class RightClickMenuApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Right Click Menu Example")
        
        self.text = tk.Text(root, width=40, height=10)
        self.text.pack(padx=10, pady=10)
        
        self.menu = tk.Menu(root, tearoff=0)
        self.sub_menu = tk.Menu(self.menu, tearoff=0)
        
        self.entry = tk.Entry(self.sub_menu)
        self.entry.pack(side="left", padx=10, pady=10)
        
        self.ok_button = tk.Button(self.sub_menu, text="确定", command=self.input_number)
        self.ok_button.pack(side="left", padx=5, pady=10)
        
        self.menu.add_cascade(label="输入数字", menu=self.sub_menu)
        
        self.text.bind("<Button-3>", self.show_menu)
    
    def show_menu(self, event):
        self.menu.post(event.x_root, event.y_root)
    
    def input_number(self):
        try:
            number = int(self.entry.get())
            self.text.insert(tk.END, f"输入的数字是: {number}\n")
        except ValueError:
            tk.messagebox.showerror("输入错误", "请输入一个有效的数字")
        self.entry.delete(0, tk.END)  # Clear the entry after submission

if __name__ == "__main__":
    root = tk.Tk()
    app = RightClickMenuApp(root)
    root.mainloop()
```
我需要将其融入我的程序逻辑[self.change_font_size()]中：
```
class GUI:
    def __init__(self, date_year, title_name, condition, font_name, font_size, time_format, window_width, window_height, position_right, position_down):
        self.root = Tk()
        self.title_name = title_name
        self.root.title(self.title_name)
        self.root.protocol("WM_DELETE_WINDOW", self.toggle_window_visibility)
        self.running = True
        self.initialize(date_year, title_name, condition, font_name, font_size, time_format, window_width, window_height, position_right, position_down)  # 初始化界面
        self.create_systray_icon()
        self.update_time()
        threading.Thread(target=self.handle_requests, daemon=True).start()  # 启动处理请求的线程（多线程）
    def create_systray_icon(self):
        precision_submenu_2 = pystray.Menu(
            pystray.MenuItem("字体大小", self.change_font_size)
        )
        main_menu = pystray.Menu(
            pystray.MenuItem("其他设置", precision_submenu_2)
        )
        image = Image.open("_internal\\image.ico")
        self.icon = pystray.Icon("icon", image, "高考倒计时", main_menu)
        threading.Thread(target=self.icon.run, daemon=True).start()

if __name__ == "__main__":
    gui = GUI(date_year, title_name, condition, font_name, font_size, time_format, window_width, window_height, position_right, position_down)
    gui.root.mainloop()
```
