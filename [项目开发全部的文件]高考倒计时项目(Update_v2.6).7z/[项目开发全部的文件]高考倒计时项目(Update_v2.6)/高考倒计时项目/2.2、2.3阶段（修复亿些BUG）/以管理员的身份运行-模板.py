import os
import sys
import ctypes
import win32com.client
import pythoncom

class AutoStartManager:
    def __init__(self, exe_path, shortcut_path):
        self.exe_path = exe_path
        self.shortcut_path = shortcut_path

    # 获取lnk文件内部指向的exe程序路径
    def get_shortcut_target(self, shortcut_path):
        shell = win32com.client.Dispatch("WScript.Shell")
        shortcut = shell.CreateShortcut(shortcut_path)
        return os.path.abspath(shortcut.TargetPath)

    # 创建程序快捷方式
    def create_shortcut(self, exe_path, shortcut_path):
        try:
            startup_dir = os.path.dirname(shortcut_path)
            if not os.path.exists(startup_dir):
                os.makedirs(startup_dir)
            
            shell = win32com.client.Dispatch("WScript.Shell")
            shortcut = shell.CreateShortCut(shortcut_path)
            shortcut.Targetpath = exe_path
            shortcut.WorkingDirectory = os.path.dirname(exe_path)
            shortcut.save()
            print("Shortcut created successfully.")
        except Exception as e:
            print(f"An error occurred: {e}")

    # 删除快捷方式
    def remove_shortcut(self, shortcut_path):
        if os.path.exists(shortcut_path):
            os.remove(shortcut_path)

    # 检测快捷方式是否存在
    def is_shortcut_exist(self):
        return os.path.exists(self.shortcut_path)

    # "开机自启动"右键菜单主逻辑
    def toggle_autostart(self):
        if self.is_shortcut_exist():
            self.remove_shortcut(self.shortcut_path)
        else:
            self.create_shortcut(self.exe_path, self.shortcut_path)

def is_admin():
    """检查是否具有管理员权限"""
    try:
        return ctypes.windll.shell32.IsUserAnAdmin()
    except:
        return False

if __name__ == "__main__":
    exe_path = sys.executable  # 可执行文件路径
    shortcut_path = "C:\\ProgramData\\Microsoft\\Windows\\Start Menu\\Programs\\StartUp\\2025高考倒计时.lnk"  # 快捷方式路径

    manager = AutoStartManager(exe_path, shortcut_path)

    if not is_admin():
        # 重新以管理员权限运行脚本
        script = os.path.abspath(sys.argv[0])
        params = ' '.join([f'"{script}"'] + sys.argv[1:])
        ctypes.windll.shell32.ShellExecuteW(None, "runas", sys.executable, params, None, 1)
    else:
        # 运行需要管理员权限的功能
        manager.toggle_autostart()
