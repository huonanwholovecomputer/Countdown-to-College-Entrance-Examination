import pystray
from tkinter import simpledialog, Tk
from PIL import Image, ImageDraw

class MyApp:
    def __init__(self):
        self.custom_font = {'size': 12}  # 示例初始字体大小
        self.root = Tk()
        self.root.withdraw()  # 隐藏主窗口

    def change_font_size(self, icon, item):
        new_font_size = simpledialog.askinteger("字体大小", "请输入新的字体大小：", initialvalue=self.custom_font["size"])
        if new_font_size:
            self.custom_font["size"] = new_font_size
            print(f"调试信息：修改了字体大小：{new_font_size}")

    def create_systray_icon(self):
        precision_submenu_2 = pystray.Menu(
            pystray.MenuItem("字体大小", self.change_font_size)
        )
        main_menu = pystray.Menu(
            pystray.MenuItem("其他设置", precision_submenu_2)
        )
        icon_image = Image.new('RGB', (64, 64), color='white')
        icon_draw = ImageDraw.Draw(icon_image)
        icon_draw.rectangle((0, 0, 64, 64), fill="black")

        icon = pystray.Icon("test_icon", icon_image, "测试图标", main_menu)
        icon.run()

app = MyApp()
app.create_systray_icon()



from tkinter import simpledialog, Tk, font
import pystray
from PIL import Image, ImageDraw

class MyApp:
    def __init__(self):
        self.root = Tk()
        self.root.withdraw()  # 隐藏主窗口
        self.custom_font = font.Font(size=12)  # 初始化字体对象

    def change_font_size(self, icon, item):
        new_font_size = simpledialog.askinteger("字体大小", "请输入新的字体大小：", initialvalue=self.custom_font['size'])
        if new_font_size:
            self.custom_font.config(size=new_font_size)
            print(f"调试信息：修改了字体大小：{new_font_size}")

    def create_systray_icon(self):
        precision_submenu_2 = pystray.Menu(
            pystray.MenuItem("字体大小", self.change_font_size)
        )
        main_menu = pystray.Menu(
            pystray.MenuItem("其他设置", precision_submenu_2)
        )
        icon_image = Image.new('RGB', (64, 64), color='white')
        icon_draw = ImageDraw.Draw(icon_image)
        icon_draw.rectangle((0, 0, 64, 64), fill="black")

        icon = pystray.Icon("test_icon", icon_image, "测试图标", main_menu)
        icon.run()

app = MyApp()
app.create_systray_icon()



import pystray
from tkinter import simpledialog, Tk, font
from PIL import Image, ImageDraw

class MyApp:
    def __init__(self):
        self.root = Tk()
        self.root.withdraw()  # 隐藏主窗口
        self.font_name = "Arial"  # 示例字体名称
        self.font_size = 12  # 示例字体大小
        self.custom_font = font.Font(family=self.font_name, size=self.font_size)  # 设置字体和字体大小

    def change_font_size(self, icon, item):
        new_font_size = simpledialog.askinteger("字体大小", "请输入新的字体大小：", initialvalue=self.custom_font.cget("size"))
        if new_font_size:
            self.custom_font.config(size=new_font_size)
            print(f"调试信息：修改了字体大小：{new_font_size}")

    def create_systray_icon(self):
        precision_submenu_2 = pystray.Menu(
            pystray.MenuItem("字体大小", self.change_font_size)
        )
        main_menu = pystray.Menu(
            pystray.MenuItem("其他设置", precision_submenu_2)
        )
        icon_image = Image.new('RGB', (64, 64), color='white')
        icon_draw = ImageDraw.Draw(icon_image)
        icon_draw.rectangle((0, 0, 64, 64), fill="black")

        icon = pystray.Icon("test_icon", icon_image, "测试图标", main_menu)
        icon.run()

app = MyApp()
app.create_systray_icon()