一、要在 Python 中创建一个带有输入框的右键菜单，你可以使用 `tkinter` 库。以下是一个示例代码，展示了如何创建这样的右键菜单，其中包含一个带有输入框的选项。

```python
import tkinter as tk
from tkinter import simpledialog

class RightClickMenuApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Right Click Menu Example")
        
        self.text = tk.Text(root, width=40, height=10)
        self.text.pack(padx=10, pady=10)
        
        self.menu = tk.Menu(root, tearoff=0)
        self.menu.add_command(label="输入数字", command=self.input_number)
        
        self.text.bind("<Button-3>", self.show_menu)
    
    def show_menu(self, event):
        self.menu.post(event.x_root, event.y_root)
    
    def input_number(self):
        number = simpledialog.askinteger("输入数字", "请输入一个数字:")
        if number is not None:
            self.text.insert(tk.END, f"输入的数字是: {number}\n")

if __name__ == "__main__":
    root = tk.Tk()
    app = RightClickMenuApp(root)
    root.mainloop()
```

上述代码的主要步骤如下：

1. 导入 `tkinter` 库和 `simpledialog` 模块。
2. 创建一个主应用程序类 `RightClickMenuApp`，在初始化时设置窗口标题和文本区域。
3. 创建一个右键菜单，其中包含一个选项 "输入数字"。
4. 绑定右键单击事件，以显示菜单。
5. 定义 `input_number` 方法，通过 `simpledialog.askinteger` 方法弹出一个输入框，提示用户输入数字，并将输入的数字显示在文本区域中。

运行该代码后，你可以右键单击文本区域，选择“输入数字”，并在弹出的对话框中输入数字。输入的数字会显示在文本区域中。




二、
除了 `simpledialog.askinteger` 方法外，你还可以通过在右键菜单中弹出一个自定义的输入框窗口来输入数字并返回程序。这可以通过创建一个新的 `Toplevel` 窗口来实现。以下是一个示例代码：

```python
import tkinter as tk

class NumberInputDialog(tk.Toplevel):
    def __init__(self, parent):
        super().__init__(parent)
        self.title("输入数字")
        
        self.label = tk.Label(self, text="请输入一个数字:")
        self.label.pack(padx=10, pady=10)
        
        self.entry = tk.Entry(self)
        self.entry.pack(padx=10, pady=10)
        
        self.button_frame = tk.Frame(self)
        self.button_frame.pack(pady=10)
        
        self.ok_button = tk.Button(self.button_frame, text="确定", command=self.on_ok)
        self.ok_button.pack(side="left", padx=5)
        
        self.cancel_button = tk.Button(self.button_frame, text="取消", command=self.on_cancel)
        self.cancel_button.pack(side="left", padx=5)
        
        self.result = None
    
    def on_ok(self):
        try:
            self.result = int(self.entry.get())
            self.destroy()
        except ValueError:
            tk.messagebox.showerror("输入错误", "请输入一个有效的数字")
    
    def on_cancel(self):
        self.destroy()

class RightClickMenuApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Right Click Menu Example")
        
        self.text = tk.Text(root, width=40, height=10)
        self.text.pack(padx=10, pady=10)
        
        self.menu = tk.Menu(root, tearoff=0)
        self.menu.add_command(label="输入数字", command=self.input_number)
        
        self.text.bind("<Button-3>", self.show_menu)
    
    def show_menu(self, event):
        self.menu.post(event.x_root, event.y_root)
    
    def input_number(self):
        dialog = NumberInputDialog(self.root)
        self.root.wait_window(dialog)
        if dialog.result is not None:
            self.text.insert(tk.END, f"输入的数字是: {dialog.result}\n")

if __name__ == "__main__":
    root = tk.Tk()
    app = RightClickMenuApp(root)
    root.mainloop()
```

这个代码片段做了以下几件事：

1. 定义了一个 `NumberInputDialog` 类，它继承自 `tk.Toplevel`，用于创建一个弹出输入框窗口。
2. 在该类中，定义了一个标签、一个输入框和两个按钮（确定和取消）。
3. `on_ok` 方法用于处理确定按钮点击事件，尝试将输入转换为整数并关闭窗口。
4. `on_cancel` 方法用于处理取消按钮点击事件，直接关闭窗口。
5. 在主应用程序类 `RightClickMenuApp` 中，使用 `NumberInputDialog` 类创建输入对话框，并在用户输入后将结果显示在文本区域中。

这样，你就可以通过右键菜单弹出一个自定义输入框窗口来输入数字。



三、
除了使用 `simpledialog` 和自定义 `Toplevel` 窗口的方法，还有另一种方法是使用弹出菜单和内嵌小部件实现输入功能。以下是一个示例代码，通过在右键菜单中内嵌 `Entry` 小部件来实现输入数字功能：

```python
import tkinter as tk

class RightClickMenuApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Right Click Menu Example")
        
        self.text = tk.Text(root, width=40, height=10)
        self.text.pack(padx=10, pady=10)
        
        self.menu = tk.Menu(root, tearoff=0)
        self.sub_menu = tk.Menu(self.menu, tearoff=0)
        
        self.entry = tk.Entry(self.sub_menu)
        self.entry.pack(side="left", padx=10, pady=10)
        
        self.ok_button = tk.Button(self.sub_menu, text="确定", command=self.input_number)
        self.ok_button.pack(side="left", padx=5, pady=10)
        
        self.menu.add_cascade(label="输入数字", menu=self.sub_menu)
        
        self.text.bind("<Button-3>", self.show_menu)
    
    def show_menu(self, event):
        self.menu.post(event.x_root, event.y_root)
    
    def input_number(self):
        try:
            number = int(self.entry.get())
            self.text.insert(tk.END, f"输入的数字是: {number}\n")
        except ValueError:
            tk.messagebox.showerror("输入错误", "请输入一个有效的数字")
        self.entry.delete(0, tk.END)  # Clear the entry after submission

if __name__ == "__main__":
    root = tk.Tk()
    app = RightClickMenuApp(root)
    root.mainloop()
```

这个代码实现了以下功能：

1. 创建一个主窗口和文本区域。
2. 创建一个右键菜单，其中包含一个子菜单，用于嵌入 `Entry` 小部件和一个确定按钮。
3. 在用户右键单击时，显示右键菜单。
4. 在用户点击确定按钮时，获取 `Entry` 中的值，并尝试将其转换为整数。如果转换成功，则将输入的数字显示在文本区域中；否则，显示错误消息。

这种方法通过在右键菜单中内嵌小部件，实现了更加紧凑和集成的用户界面。



四、
另外一种方法是通过使用 `tkinter` 的 `Canvas` 小部件来实现类似的功能。你可以在右键单击时，在 `Canvas` 上创建一个弹出输入框。这种方法可以使输入框更灵活地出现在指定位置。以下是一个示例代码：

```python
import tkinter as tk

class RightClickMenuApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Right Click Menu Example")
        
        self.canvas = tk.Canvas(root, width=400, height=300)
        self.canvas.pack(padx=10, pady=10)
        
        self.canvas.bind("<Button-3>", self.show_menu)
    
    def show_menu(self, event):
        self.popup_menu(event.x, event.y)
    
    def popup_menu(self, x, y):
        # Create a frame to hold the Entry and Button
        self.popup = tk.Frame(self.canvas, bg="white", bd=1, relief="solid")
        self.popup.place(x=x, y=y)
        
        self.entry = tk.Entry(self.popup)
        self.entry.pack(side="left", padx=5, pady=5)
        
        self.ok_button = tk.Button(self.popup, text="确定", command=self.input_number)
        self.ok_button.pack(side="left", padx=5, pady=5)
    
    def input_number(self):
        try:
            number = int(self.entry.get())
            self.canvas.create_text(200, 150, text=f"输入的数字是: {number}", fill="black")
        except ValueError:
            tk.messagebox.showerror("输入错误", "请输入一个有效的数字")
        self.popup.destroy()  # Remove the popup after submission

if __name__ == "__main__":
    root = tk.Tk()
    app = RightClickMenuApp(root)
    root.mainloop()
```

这个代码实现了以下功能：

1. 创建一个主窗口和 `Canvas` 小部件。
2. 在 `Canvas` 上绑定右键单击事件，以显示弹出菜单。
3. 在 `Canvas` 上创建一个 `Frame`，其中包含一个 `Entry` 小部件和一个确定按钮。
4. 在用户点击确定按钮时，获取 `Entry` 中的值，并尝试将其转换为整数。如果转换成功，则在 `Canvas` 上显示输入的数字；否则，显示错误消息。
5. 在输入完成后，销毁弹出框。

这种方法通过在 `Canvas` 上动态创建输入框，实现了更加灵活的位置控制，使输入框可以在任意位置弹出。



五、
另一种方法是使用 `tkinter` 的 `PopupMenu` 和自定义的输入窗口来实现。这种方法结合了菜单和弹出窗口的优势，可以更灵活地处理用户输入。以下是一个示例代码：

```python
import tkinter as tk

class InputPopup(tk.Toplevel):
    def __init__(self, parent):
        super().__init__(parent)
        self.title("输入数字")
        self.geometry("200x100")
        
        self.label = tk.Label(self, text="请输入一个数字:")
        self.label.pack(pady=5)
        
        self.entry = tk.Entry(self)
        self.entry.pack(pady=5)
        
        self.button = tk.Button(self, text="确定", command=self.on_submit)
        self.button.pack(pady=5)
        
        self.result = None
    
    def on_submit(self):
        try:
            self.result = int(self.entry.get())
            self.destroy()
        except ValueError:
            tk.messagebox.showerror("输入错误", "请输入一个有效的数字")

class RightClickMenuApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Right Click Menu Example")
        
        self.text = tk.Text(root, width=40, height=10)
        self.text.pack(padx=10, pady=10)
        
        self.menu = tk.Menu(root, tearoff=0)
        self.menu.add_command(label="输入数字", command=self.open_input_popup)
        
        self.text.bind("<Button-3>", self.show_menu)
    
    def show_menu(self, event):
        self.menu.post(event.x_root, event.y_root)
    
    def open_input_popup(self):
        input_popup = InputPopup(self.root)
        self.root.wait_window(input_popup)
        if input_popup.result is not None:
            self.text.insert(tk.END, f"输入的数字是: {input_popup.result}\n")

if __name__ == "__main__":
    root = tk.Tk()
    app = RightClickMenuApp(root)
    root.mainloop()
```

这个代码实现了以下功能：

1. 创建一个 `InputPopup` 类，继承自 `tk.Toplevel`，用于弹出一个输入窗口。
2. 在 `InputPopup` 类中，定义标签、输入框和确定按钮，处理用户输入。
3. 在主应用程序类 `RightClickMenuApp` 中，创建右键菜单，并添加一个选项用于弹出 `InputPopup` 输入窗口。
4. 在用户右键单击时，显示右键菜单。
5. 在用户点击菜单中的“输入数字”选项时，弹出 `InputPopup` 输入窗口，并在用户输入数字后，将结果显示在文本区域中。

这种方法通过分离菜单和输入窗口，实现了更清晰的结构和更灵活的输入处理。